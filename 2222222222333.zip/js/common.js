(function ($) {
	"use strict";

	var $body = $("body");
	var $modal = $("#modal");
	var $formModal = $("#f4");
	var $thanks = $("#thanks");
	var $nav = $(".main-nav");
	var $mobileNav = $("#nav-menu");
	var $toggle = $(".nav-toggle");
	var $toTop = $("#to-top");
	var $header = $(".site-header");

	function openModal(showThanks) {
		$modal.removeAttr("hidden");
		if (showThanks) {
			$formModal.attr("hidden", true);
			$thanks.removeAttr("hidden");
		} else {
			$thanks.attr("hidden", true);
			$formModal.removeAttr("hidden");
		}
		$body.css("overflow", "hidden");
		$formModal.find("input").first().trigger("focus");
	}

	function closeModal() {
		$modal.attr("hidden", true);
		$formModal.attr("hidden", true);
		$thanks.attr("hidden", true);
		$body.css("overflow", "");
	}

	function closeNav() {
		$nav.removeClass("is-open");
		$mobileNav.attr("hidden", true).removeClass("is-open");
		$toggle.attr("aria-expanded", "false");
		$toggle.attr("aria-label", "Открыть меню");
		$body.removeClass("nav-open");
	}

	function openNav() {
		$nav.addClass("is-open");
		$mobileNav.removeAttr("hidden").addClass("is-open");
		$toggle.attr("aria-expanded", "true");
		$toggle.attr("aria-label", "Закрыть меню");
		$body.addClass("nav-open");
	}

	/* Mobile menu */
	$toggle.on("click", function () {
		if ($body.hasClass("nav-open")) {
			closeNav();
		} else {
			openNav();
		}
	});

	$mobileNav.on("click", "a", closeNav);

	$(document).on("keydown", function (e) {
		if (e.key === "Escape") {
			closeModal();
			closeNav();
		}
	});

	/* Smooth scroll for in-page anchors */
	$('a[href^="#"]').on("click", function (e) {
		var hash = this.getAttribute("href");
		if (!hash || hash === "#") {
			return;
		}
		var $target = $(hash);
		if (!$target.length) {
			return;
		}
		e.preventDefault();
		var offset = $header.outerHeight() || 72;
		$("html, body").animate(
			{ scrollTop: $target.offset().top - offset },
			450
		);
	});

	/* Modal open / close */
	$(".buying").on("click", function (e) {
		e.preventDefault();
		openModal(false);
	});

	$modal.on("click", "[data-close-modal]", function () {
		closeModal();
	});

	/* Belarus phone mask */
	$("input[name='phone']").mask("+375 (99) 999-99-99");

	/* Basic HTML5 + jQuery Validate if available */
	if ($.fn.validate) {
		$("#f1, #f2, #f3, #f4").each(function () {
			$(this).validate({
				errorPlacement: function () {},
				highlight: function (el) {
					$(el).addClass("error");
				},
				unhighlight: function (el) {
					$(el).removeClass("error");
				}
			});
		});
	}

	/* Header shadow + back-to-top */
	function onScroll() {
		var top = $(window).scrollTop();
		$header.toggleClass("is-scrolled", top > 20);
		$toTop.toggleClass("is-visible", top > 900);
	}

	$(window).on("scroll", onScroll);
	onScroll();

	/* Reveal on scroll */
	var revealEls = document.querySelectorAll(".reveal");
	if ("IntersectionObserver" in window) {
		var io = new IntersectionObserver(
			function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) {
						entry.target.classList.add("is-visible");
						io.unobserve(entry.target);
					}
				});
			},
			{ threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
		);
		revealEls.forEach(function (el) {
			io.observe(el);
		});
	} else {
		revealEls.forEach(function (el) {
			el.classList.add("is-visible");
		});
	}
})(jQuery);
