/**
 * Яндекс.Карты — Брест, ул. Московская, 364
 */
(function () {
	"use strict";

	var ADDRESS = "Беларусь, Брест, улица Московская, 364";
	var FALLBACK_CENTER = [52.097621, 23.734051]; // центр Бреста
	var MAP_ID = "yandex-map";

	function addPlacemark(map, coords) {
		var placemark = new ymaps.Placemark(
			coords,
			{
				hintContent: "Автозапчасти — ООО «БелТРЭК»",
				balloonContentHeader: "ООО «БелТРЭК»",
				balloonContentBody:
					"<p>Брест, ул. Московская, 364</p>" +
					'<p><a href="tel:+375297920786">+375 29 792 07 86</a></p>' +
					"<p>пн–пт: 9:00–21:00<br>сб–вс: 11:00–19:00</p>",
				balloonContentFooter: "Самовывоз и консультации"
			},
			{
				preset: "islands#nightCircleDotIcon",
				iconColor: "#c9a36a"
			}
		);
		map.geoObjects.add(placemark);
		map.setCenter(coords, 15, { duration: 300 });
		return placemark;
	}

	function initMap() {
		var el = document.getElementById(MAP_ID);
		if (!el || typeof ymaps === "undefined") {
			return;
		}

		var map = new ymaps.Map(
			MAP_ID,
			{
				center: FALLBACK_CENTER,
				zoom: 13,
				controls: ["zoomControl", "geolocationControl", "fullscreenControl"]
			},
			{
				suppressMapOpenBlock: true
			}
		);

		map.behaviors.disable("scrollZoom");

		ymaps.geocode(ADDRESS, { results: 1 }).then(
			function (res) {
				var first = res.geoObjects.get(0);
				if (first) {
					var coords = first.geometry.getCoordinates();
					addPlacemark(map, coords);
				} else {
					addPlacemark(map, FALLBACK_CENTER);
				}
			},
			function () {
				addPlacemark(map, FALLBACK_CENTER);
			}
		);

		window.addEventListener("resize", function () {
			map.container.fitToViewport();
		});
	}

	function boot() {
		if (typeof ymaps === "undefined") {
			return;
		}
		ymaps.ready(initMap);
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", boot);
	} else {
		boot();
	}
})();
